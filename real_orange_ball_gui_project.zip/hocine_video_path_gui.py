"""
Hocine's GUI job - Real orange ball video path logger

Capstone purpose
----------------
This program is the GUI/data-logging part of the dodgeball robot project, specifically built around the real orange table-tennis/ping-pong ball used in testing.
It accepts a video input, streams it in a Tkinter GUI, detects the orange ball in frame coordinates, draws the ball trajectory live, saves every frame's ball location information, shows previous paths in different colors, and can delete or export saved paths.

Main features
-------------
1. Load video from computer.
2. Play, pause, restart, and step frame-by-frame.
3. Detect ball using OpenCV HSV color segmentation and contour filtering.
4. Correctly supports red/orange balls even when HSV hue wraps around 0/179.
5. Draw live path while the video is rolling.
6. Save frame-by-frame location info: frame, timestamp, x, y, radius, detected.
7. Save previous paths to JSON and show them with different color codes.
8. Delete saved paths.
9. Export current path to CSV.
10. Save annotated video with detected path overlay.

Install
-------
    pip install opencv-python pillow numpy

Run
---
    python hocine_video_path_gui.py

Recommended ball setup
----------------------
Use the real orange table-tennis/ping-pong ball shown in the project test image and keep lighting stable. If the circle is not on
the ball, adjust the HSV sliders. For a red ball, it is normal to set H min
larger than H max; the program automatically treats that as a wrap-around hue
range.
"""

from __future__ import annotations

import csv
import json
import os
import time
import tkinter as tk
from dataclasses import asdict, dataclass
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Any, Dict, Iterable, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image, ImageTk

APP_DIR = Path(__file__).resolve().parent
SAVE_FILE = APP_DIR / "saved_ball_paths.json"
CSV_FOLDER = APP_DIR / "path_exports"
ANNOTATED_FOLDER = APP_DIR / "annotated_videos"
MAX_DISPLAY_WIDTH = 960
MAX_DISPLAY_HEIGHT = 540

BGRColor = Tuple[int, int, int]
Point2D = Tuple[int, int]


@dataclass
class BallPoint:
    frame: int
    time_sec: float
    x: Optional[int]
    y: Optional[int]
    radius: Optional[float]
    detected: bool


class BallDetector:
    """OpenCV ball detector isolated from the GUI so it can be tested easily."""

    def __init__(
        self,
        h_min: int = 0,
        h_max: int = 25,
        s_min: int = 80,
        s_max: int = 255,
        v_min: int = 80,
        v_max: int = 255,
        min_area: int = 120,
        min_radius: float = 3.0,
    ) -> None:
        self.h_min = int(h_min)
        self.h_max = int(h_max)
        self.s_min = int(s_min)
        self.s_max = int(s_max)
        self.v_min = int(v_min)
        self.v_max = int(v_max)
        self.min_area = int(min_area)
        self.min_radius = float(min_radius)

    def make_mask(self, frame_bgr: np.ndarray) -> np.ndarray:
        blurred = cv2.GaussianBlur(frame_bgr, (7, 7), 0)
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

        # OpenCV hue range is 0..179. Red/orange can cross the boundary.
        # Example: h_min=170, h_max=15 means [170..179] OR [0..15].
        if self.h_min <= self.h_max:
            lower = np.array([self.h_min, self.s_min, self.v_min], dtype=np.uint8)
            upper = np.array([self.h_max, self.s_max, self.v_max], dtype=np.uint8)
            mask = cv2.inRange(hsv, lower, upper)
        else:
            lower1 = np.array([self.h_min, self.s_min, self.v_min], dtype=np.uint8)
            upper1 = np.array([179, self.s_max, self.v_max], dtype=np.uint8)
            lower2 = np.array([0, self.s_min, self.v_min], dtype=np.uint8)
            upper2 = np.array([self.h_max, self.s_max, self.v_max], dtype=np.uint8)
            mask = cv2.bitwise_or(cv2.inRange(hsv, lower1, upper1), cv2.inRange(hsv, lower2, upper2))

        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        return mask

    def detect(self, frame_bgr: np.ndarray) -> Optional[Tuple[int, int, float]]:
        mask = self.make_mask(frame_bgr)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        candidates = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area < self.min_area:
                continue
            perimeter = cv2.arcLength(contour, True)
            circularity = 0.0 if perimeter == 0 else 4 * np.pi * area / (perimeter * perimeter)
            (x, y), radius = cv2.minEnclosingCircle(contour)
            if radius < self.min_radius:
                continue
            # Score favors large, round objects.
            candidates.append((area * max(circularity, 0.25), x, y, radius))

        if not candidates:
            return None
        _, x, y, radius = max(candidates, key=lambda item: item[0])
        return int(round(x)), int(round(y)), float(radius)


class BallPathGUI:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Dodgeball Robot - Real Orange Ball Path GUI")
        self.root.geometry("1220x780")

        self.cap: Optional[cv2.VideoCapture] = None
        self.video_path: Optional[str] = None
        self.playing = False
        self.after_id: Optional[str] = None
        self.show_previous = False

        self.frame_index = 0
        self.total_frames = 0
        self.fps = 30.0
        self.delay_ms = 33
        self.scale = 1.0

        self.current_points: List[BallPoint] = []
        self.saved_paths: List[Dict[str, Any]] = self.load_saved_paths()
        self.last_frame_bgr: Optional[np.ndarray] = None
        self.last_ball: Optional[Tuple[int, int, float]] = None

        # Default tuned for the real orange table-tennis/ping-pong ball. For pure red, use preset button.
        self.h_min = tk.IntVar(value=0)
        self.h_max = tk.IntVar(value=25)
        self.s_min = tk.IntVar(value=80)
        self.s_max = tk.IntVar(value=255)
        self.v_min = tk.IntVar(value=80)
        self.v_max = tk.IntVar(value=255)
        self.min_area = tk.IntVar(value=120)

        self.status_text = tk.StringVar(value="Load a video to start.")
        self.detection_text = tk.StringVar(value="Ball: not detected")
        self.video_text = tk.StringVar(value="No video selected")
        self.stats_text = tk.StringVar(value="Saved paths: 0")

        self.build_ui()
        self.refresh_stats()

    def build_ui(self) -> None:
        top = tk.Frame(self.root)
        top.pack(side=tk.TOP, fill=tk.X, padx=8, pady=6)

        buttons = [
            ("Load Input Video", self.load_video, 17),
            ("Play / Pause", self.toggle_play, 13),
            ("Step Frame", self.step_one_frame, 12),
            ("Restart", self.restart_video, 10),
            ("Save Current Path", self.save_current_path, 17),
            ("Show Previous Paths", self.toggle_previous_paths, 19),
            ("Delete Saved Paths", self.delete_saved_paths, 18),
            ("Export CSV", self.export_current_csv, 11),
            ("Save Annotated Video", self.export_annotated_video, 18),
        ]
        for text, command, width in buttons:
            tk.Button(top, text=text, command=command, width=width).pack(side=tk.LEFT, padx=3)

        main = tk.Frame(self.root)
        main.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)

        self.video_label = tk.Label(main, bg="black")
        self.video_label.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        panel = tk.Frame(main, width=280)
        panel.pack(side=tk.RIGHT, fill=tk.Y, padx=8)
        panel.pack_propagate(False)

        tk.Label(panel, text="Detection Settings", font=("Arial", 13, "bold")).pack(anchor="w", pady=(0, 8))
        preset_frame = tk.Frame(panel)
        preset_frame.pack(fill=tk.X, pady=(0, 6))
        tk.Button(preset_frame, text="Orange preset", command=self.set_orange_preset).pack(side=tk.LEFT, padx=2)
        tk.Button(preset_frame, text="Red preset", command=self.set_red_preset).pack(side=tk.LEFT, padx=2)

        self.add_slider(panel, "H min", self.h_min, 0, 179)
        self.add_slider(panel, "H max", self.h_max, 0, 179)
        self.add_slider(panel, "S min", self.s_min, 0, 255)
        self.add_slider(panel, "S max", self.s_max, 0, 255)
        self.add_slider(panel, "V min", self.v_min, 0, 255)
        self.add_slider(panel, "V max", self.v_max, 0, 255)
        self.add_slider(panel, "Min contour area", self.min_area, 10, 5000)

        tk.Label(panel, text="Status", font=("Arial", 13, "bold")).pack(anchor="w", pady=(14, 6))
        for var in (self.video_text, self.detection_text, self.status_text, self.stats_text):
            tk.Label(panel, textvariable=var, wraplength=260, justify="left").pack(anchor="w", pady=3)

        tk.Label(panel, text="Workflow", font=("Arial", 13, "bold")).pack(anchor="w", pady=(14, 6))
        instructions = (
            "1. Load Input Video.\n"
            "2. Tune HSV until the circle follows the ball.\n"
            "3. Let the video play; the path is drawn live.\n"
            "4. Save Current Path.\n"
            "5. Show Previous Paths to compare trials.\n"
            "6. Export CSV for frame-by-frame location data."
        )
        tk.Label(panel, text=instructions, wraplength=260, justify="left").pack(anchor="w")

    @staticmethod
    def add_slider(parent: tk.Widget, label: str, variable: tk.IntVar, min_value: int, max_value: int) -> None:
        tk.Label(parent, text=label).pack(anchor="w")
        tk.Scale(parent, from_=min_value, to=max_value, orient=tk.HORIZONTAL, variable=variable).pack(fill=tk.X)

    def set_orange_preset(self) -> None:
        self.h_min.set(0); self.h_max.set(25); self.s_min.set(80); self.s_max.set(255); self.v_min.set(80); self.v_max.set(255); self.min_area.set(120)
        self.status_text.set("Orange ball preset applied.")

    def set_red_preset(self) -> None:
        self.h_min.set(170); self.h_max.set(15); self.s_min.set(80); self.s_max.set(255); self.v_min.set(70); self.v_max.set(255); self.min_area.set(120)
        self.status_text.set("Red ball preset applied. Hue wrap-around is active.")

    def get_detector(self) -> BallDetector:
        return BallDetector(
            h_min=self.h_min.get(), h_max=self.h_max.get(), s_min=self.s_min.get(), s_max=self.s_max.get(),
            v_min=self.v_min.get(), v_max=self.v_max.get(), min_area=self.min_area.get()
        )

    def load_video(self) -> None:
        path = filedialog.askopenfilename(
            title="Select input video",
            filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv *.wmv"), ("All files", "*.*")],
        )
        if path:
            self.open_video(path)

    def open_video(self, path: str) -> None:
        self.cancel_after()
        if self.cap is not None:
            self.cap.release()

        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            messagebox.showerror("Error", "Could not open the selected video.")
            return

        self.cap = cap
        self.video_path = path
        self.fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        self.delay_ms = max(1, int(1000 / self.fps))
        self.total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        self.frame_index = 0
        self.current_points = []
        self.playing = True
        self.video_text.set(f"Video: {Path(path).name}")
        self.status_text.set("Video loaded. Detection and path logging started.")
        self.update_frame()

    def toggle_play(self) -> None:
        if self.cap is None:
            messagebox.showinfo("No video", "Please load a video first.")
            return
        self.playing = not self.playing
        self.status_text.set("Playing." if self.playing else "Paused.")
        if self.playing:
            self.update_frame()
        else:
            self.cancel_after()

    def step_one_frame(self) -> None:
        if self.cap is None:
            messagebox.showinfo("No video", "Please load a video first.")
            return
        self.playing = False
        self.cancel_after()
        self.process_next_frame(show=True)
        self.status_text.set("Stepped one frame.")

    def restart_video(self) -> None:
        if self.cap is None:
            return
        self.cancel_after()
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        self.frame_index = 0
        self.current_points = []
        self.playing = True
        self.status_text.set("Video restarted. Current path cleared.")
        self.update_frame()

    def cancel_after(self) -> None:
        if self.after_id is not None:
            try:
                self.root.after_cancel(self.after_id)
            except Exception:
                pass
            self.after_id = None

    def update_frame(self) -> None:
        if self.cap is None or not self.playing:
            return
        success = self.process_next_frame(show=True)
        if success and self.playing:
            self.after_id = self.root.after(self.delay_ms, self.update_frame)
        elif not success:
            self.playing = False
            self.status_text.set("Video finished. Save or export the path if needed.")

    def process_next_frame(self, show: bool = True) -> bool:
        if self.cap is None:
            return False
        ret, frame = self.cap.read()
        if not ret:
            return False

        self.last_frame_bgr = frame.copy()
        self.frame_index = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES))
        time_sec = self.frame_index / self.fps if self.fps > 0 else 0.0

        ball = self.get_detector().detect(frame)
        self.last_ball = ball
        if ball is not None:
            x, y, radius = ball
            self.current_points.append(BallPoint(self.frame_index, time_sec, x, y, radius, True))
            self.detection_text.set(f"Ball: x={x}, y={y}, radius={radius:.1f}px")
        else:
            self.current_points.append(BallPoint(self.frame_index, time_sec, None, None, None, False))
            self.detection_text.set("Ball: not detected")

        if show:
            self.show_frame(self.draw_overlay(frame, ball))
        self.refresh_stats()
        return True

    def draw_overlay(self, frame: np.ndarray, ball: Optional[Tuple[int, int, float]]) -> np.ndarray:
        output = frame.copy()
        if self.show_previous:
            for idx, path in enumerate(self.saved_paths):
                color = self.color_for_index(idx)
                pts = [(p["x"], p["y"]) for p in path.get("points", []) if p.get("detected") and p.get("x") is not None and p.get("y") is not None]
                self.draw_polyline(output, pts, color, thickness=2)

        current_pts = [(p.x, p.y) for p in self.current_points if p.detected and p.x is not None and p.y is not None]
        self.draw_polyline(output, current_pts, (0, 255, 255), thickness=3)

        if ball is not None:
            x, y, radius = ball
            cv2.circle(output, (x, y), int(radius), (0, 255, 0), 2)
            cv2.circle(output, (x, y), 4, (0, 0, 255), -1)
            cv2.putText(output, f"Ball ({x},{y})", (x + 10, max(20, y - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        detected = sum(1 for p in self.current_points if p.detected)
        cv2.putText(output, f"Frame: {self.frame_index}/{self.total_frames or '?'}", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)
        cv2.putText(output, f"Detected path points: {detected}", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)
        return output

    @staticmethod
    def draw_polyline(image: np.ndarray, pts: Iterable[Point2D], color: BGRColor, thickness: int) -> None:
        pts_list = [(int(x), int(y)) for x, y in pts]
        if len(pts_list) >= 2:
            cv2.polylines(image, [np.array(pts_list, dtype=np.int32)], isClosed=False, color=color, thickness=thickness)

    @staticmethod
    def color_for_index(idx: int) -> BGRColor:
        palette = [
            (255, 0, 0), (0, 255, 0), (0, 0, 255),
            (255, 255, 0), (255, 0, 255), (0, 255, 255),
            (128, 255, 0), (255, 128, 0), (128, 0, 255), (0, 128, 255),
        ]
        return palette[idx % len(palette)]

    def show_frame(self, frame_bgr: np.ndarray) -> None:
        h, w = frame_bgr.shape[:2]
        self.scale = min(MAX_DISPLAY_WIDTH / w, MAX_DISPLAY_HEIGHT / h, 1.0)
        if self.scale < 1.0:
            frame_bgr = cv2.resize(frame_bgr, (int(w * self.scale), int(h * self.scale)))
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        self.video_label.imgtk = imgtk
        self.video_label.configure(image=imgtk)

    def save_current_path(self) -> None:
        detected_count = sum(1 for p in self.current_points if p.detected)
        if detected_count == 0:
            messagebox.showwarning("No detected path", "No ball locations were detected in this video yet.")
            return
        path_record = {
            "id": int(time.time() * 1000),
            "video_name": Path(self.video_path or "unknown_video").name,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "fps": self.fps,
            "total_logged_frames": len(self.current_points),
            "detected_points": detected_count,
            "points": [asdict(p) for p in self.current_points],
        }
        self.saved_paths.append(path_record)
        self.write_saved_paths()
        self.refresh_stats()
        self.status_text.set(f"Saved current path with {detected_count} detected ball points.")
        messagebox.showinfo("Saved", "Current path was saved successfully.")

    def toggle_previous_paths(self) -> None:
        self.show_previous = not self.show_previous
        self.status_text.set("Previous paths are visible." if self.show_previous else "Previous paths are hidden.")
        if self.last_frame_bgr is not None:
            self.show_frame(self.draw_overlay(self.last_frame_bgr, self.last_ball))

    def delete_saved_paths(self) -> None:
        if not self.saved_paths:
            messagebox.showinfo("No paths", "There are no saved paths to delete.")
            return
        if not messagebox.askyesno("Delete paths", "Delete all saved previous paths?"):
            return
        self.saved_paths = []
        self.write_saved_paths()
        self.refresh_stats()
        self.status_text.set("All saved paths were deleted.")

    def export_current_csv(self) -> Optional[Path]:
        if not self.current_points:
            messagebox.showwarning("No data", "There is no current path data to export.")
            return None
        CSV_FOLDER.mkdir(exist_ok=True)
        video_base = Path(self.video_path or "video").stem
        path = CSV_FOLDER / f"{video_base}_path_{int(time.time())}.csv"
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["frame", "time_sec", "x", "y", "radius", "detected"])
            writer.writeheader()
            for point in self.current_points:
                writer.writerow(asdict(point))
        self.status_text.set(f"CSV exported: {path}")
        messagebox.showinfo("Exported", f"CSV saved to:\n{path.resolve()}")
        return path

    def export_annotated_video(self) -> Optional[Path]:
        if self.cap is None or self.video_path is None:
            messagebox.showinfo("No video", "Please load a video first.")
            return None
        if not self.current_points:
            messagebox.showwarning("No data", "Play or step through the video first so there is a path to draw.")
            return None

        ANNOTATED_FOLDER.mkdir(exist_ok=True)
        input_path = Path(self.video_path)
        output_path = ANNOTATED_FOLDER / f"{input_path.stem}_annotated_{int(time.time())}.mp4"
        render_annotated_video(
            input_video=input_path,
            output_video=output_path,
            points=self.current_points,
            fps=self.fps,
            saved_paths=self.saved_paths if self.show_previous else None,
        )
        self.status_text.set(f"Annotated video saved: {output_path}")
        messagebox.showinfo("Saved", f"Annotated video saved to:\n{output_path.resolve()}")
        return output_path

    def load_saved_paths(self) -> List[Dict[str, Any]]:
        if not SAVE_FILE.exists():
            return []
        try:
            with SAVE_FILE.open("r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def write_saved_paths(self) -> None:
        with SAVE_FILE.open("w", encoding="utf-8") as f:
            json.dump(self.saved_paths, f, indent=2)

    def refresh_stats(self) -> None:
        detected = sum(1 for p in self.current_points if p.detected)
        self.stats_text.set(f"Current frames: {len(self.current_points)} | detected: {detected} | saved paths: {len(self.saved_paths)}")

    def on_close(self) -> None:
        self.cancel_after()
        if self.cap is not None:
            self.cap.release()
        self.root.destroy()


def render_annotated_video(
    input_video: Path,
    output_video: Path,
    points: List[BallPoint],
    fps: float,
    saved_paths: Optional[List[Dict[str, Any]]] = None,
) -> None:
    cap = cv2.VideoCapture(str(input_video))
    if not cap.isOpened():
        raise RuntimeError(f"Could not open input video: {input_video}")
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = fps or cap.get(cv2.CAP_PROP_FPS) or 30.0
    writer = cv2.VideoWriter(str(output_video), cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
    if not writer.isOpened():
        cap.release()
        raise RuntimeError(f"Could not create output video: {output_video}")

    by_frame = {p.frame: p for p in points}
    current_path: List[Point2D] = []
    frame_no = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_no += 1
        if saved_paths:
            for idx, path in enumerate(saved_paths):
                color = BallPathGUI.color_for_index(idx)
                prev_pts = [(p["x"], p["y"]) for p in path.get("points", []) if p.get("detected") and p.get("x") is not None and p.get("y") is not None]
                BallPathGUI.draw_polyline(frame, prev_pts, color, 2)
        p = by_frame.get(frame_no)
        if p and p.detected and p.x is not None and p.y is not None:
            current_path.append((p.x, p.y))
            BallPathGUI.draw_polyline(frame, current_path, (0, 255, 255), 3)
            if p.radius:
                cv2.circle(frame, (p.x, p.y), int(p.radius), (0, 255, 0), 2)
                cv2.circle(frame, (p.x, p.y), 4, (0, 0, 255), -1)
        else:
            BallPathGUI.draw_polyline(frame, current_path, (0, 255, 255), 3)
        cv2.putText(frame, f"Frame: {frame_no}", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)
        writer.write(frame)
    writer.release()
    cap.release()


def main() -> None:
    root = tk.Tk()
    app = BallPathGUI(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
