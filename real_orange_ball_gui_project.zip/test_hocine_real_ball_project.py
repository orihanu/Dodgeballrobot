from pathlib import Path
import importlib.util
import sys
import cv2
import numpy as np

SRC = Path('/mnt/data/hocine_video_path_gui.py')
spec = importlib.util.spec_from_file_location('hocine_gui', SRC)
mod = importlib.util.module_from_spec(spec)
sys.modules['hocine_gui'] = mod
spec.loader.exec_module(mod)

# Synthetic orange ball detector test
frame = np.zeros((240, 320, 3), dtype=np.uint8)
cv2.circle(frame, (80, 120), 18, (0, 90, 255), -1)
detector = mod.BallDetector(h_min=0, h_max=25, s_min=80, s_max=255, v_min=80, v_max=255, min_area=120)
ball = detector.detect(frame)
assert ball is not None, 'Synthetic orange ball was not detected'
x, y, r = ball
assert abs(x - 80) <= 2 and abs(y - 120) <= 2 and 15 <= r <= 23, ball

# Real uploaded ball image test
real_img = cv2.imread('/mnt/data/1E903CE2-BBD8-4EFF-B0A2-DD5863763711.jpeg')
assert real_img is not None, 'Real ball image could not be loaded'
real_ball = detector.detect(real_img)
assert real_ball is not None, 'Real orange table-tennis ball was not detected'
rx, ry, rr = real_ball
assert 430 <= rx <= 590 and 250 <= ry <= 410 and 80 <= rr <= 190, f'Unexpected real ball detection: {real_ball}'

# Create annotated image proof
proof = real_img.copy()
cv2.circle(proof, (rx, ry), int(rr), (0, 255, 0), 4)
cv2.circle(proof, (rx, ry), 6, (0, 0, 255), -1)
cv2.putText(proof, f'Real ball detected: x={rx}, y={ry}, r={rr:.1f}', (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 3)
proof_path = Path('/mnt/data/real_ball_detection_proof.jpg')
cv2.imwrite(str(proof_path), proof)

# Synthetic video tracking test
video_path = Path('/mnt/data/real_ball_project_synthetic_path.mp4')
out_path = Path('/mnt/data/real_ball_project_annotated_path.mp4')
fps = 20
writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*'mp4v'), fps, (320, 240))
points = []
for i in range(1, 31):
    fr = np.zeros((240, 320, 3), dtype=np.uint8)
    cx, cy = 20 + i * 8, 40 + i * 4
    cv2.circle(fr, (cx, cy), 14, (0, 90, 255), -1)
    writer.write(fr)
    detected = detector.detect(fr)
    assert detected is not None, f'No detection at synthetic frame {i}'
    dx, dy, dr = detected
    points.append(mod.BallPoint(frame=i, time_sec=i / fps, x=dx, y=dy, radius=dr, detected=True))
writer.release()
mod.render_annotated_video(video_path, out_path, points, fps)
assert out_path.exists() and out_path.stat().st_size > 1000, 'Annotated video was not created'

print('ALL REAL BALL PROJECT TESTS PASSED')
print(f'Real ball detection: x={rx}, y={ry}, radius={rr:.1f}')
print(f'Proof image: {proof_path}')
print(f'Annotated path video: {out_path}')
