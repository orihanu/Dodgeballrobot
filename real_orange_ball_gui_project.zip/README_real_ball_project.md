# Real Orange Ball Path Detection GUI

This is Hocine's GUI subsystem for the dodgeball robot project. The project is now centered on the real orange table-tennis/ping-pong ball shown in the test image.

## What the GUI does

- Takes a video from the computer.
- Streams the video inside the GUI.
- Detects the real orange ball using HSV color segmentation.
- Draws the ball path while the video is playing.
- Saves ball location data for every frame.
- Exports frame-by-frame data to CSV.
- Saves the current path.
- Shows previous saved paths with different colors.
- Deletes saved paths.
- Exports an annotated video with the path overlay.

## Detection method

The detector uses classical computer vision:

1. Gaussian blur
2. BGR to HSV conversion
3. Orange HSV thresholding
4. Morphological cleaning
5. Largest circular contour selection
6. Minimum enclosing circle
7. Path drawing and CSV logging

This fits the capstone design choice because the ball has a known color and the test environment is controlled.

## Logged CSV format

| frame | time_sec | x | y | radius | detected |
|---|---:|---:|---:|---:|---|

Each row represents the ball location in one video frame.

## Install

```bash
pip install opencv-python pillow numpy
```

## Run

```bash
python hocine_video_path_gui.py
```

## Tested

The test file checks:

- synthetic orange ball detection
- real uploaded ball image detection
- annotated proof image generation
- synthetic moving-ball video path tracking
- annotated video export

Run:

```bash
python test_hocine_real_ball_project.py
```

Expected output:

```text
ALL REAL BALL PROJECT TESTS PASSED
```
